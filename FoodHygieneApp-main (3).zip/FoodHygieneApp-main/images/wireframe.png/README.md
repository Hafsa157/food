
![wireframe1](https://github.com/user-attachments/assets/3f3c2659-c279-4cbf-8a89-0cea6e1e8ece)



![wireframe2](https://github.com/user-attachments/assets/a4824458-161f-410c-a194-75dc116a31e8)




![wireframe3](https://github.com/user-attachments/assets/3204faf5-c621-490e-866c-b58e05c96f0c)
