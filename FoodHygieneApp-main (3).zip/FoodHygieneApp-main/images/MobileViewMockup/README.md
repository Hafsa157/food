# Mobile View Mockup - Created by Hafsa Robleh


<img width="552" alt="Screenshot 2025-01-13 at 18 27 28" src="https://github.com/user-attachments/assets/64ff00b8-db14-42b4-99d7-aeb61bb7e672" />








<img width="559" alt="Screenshot 2025-01-13 at 18 26 34" src="https://github.com/user-attachments/assets/491dd292-ed5c-4ec2-bd64-f8363ee08a38" />








<img width="555" alt="Screenshot 2025-01-13 at 18 28 54" src="https://github.com/user-attachments/assets/a7d0416a-e883-48df-b993-def2e58cf31a" />









<img width="558" alt="Screenshot 2025-01-13 at 18 30 07" src="https://github.com/user-attachments/assets/ee629fd0-834b-4dc0-a92f-d19631e8061a" />









<img width="553" alt="Screenshot 2025-01-13 at 18 32 41" src="https://github.com/user-attachments/assets/c9efae7f-c7cd-4f8d-9bc2-102041438aa0" />









<img width="549" alt="Screenshot 2025-01-13 at 18 34 08" src="https://github.com/user-attachments/assets/cd6dd9e8-8640-4076-accf-72b6a757a5de" />








<img width="563" alt="Screenshot 2025-01-13 at 18 34 40" src="https://github.com/user-attachments/assets/800ca3a2-76cb-4e6d-89c7-c8c2062e8ba7" />









<img width="559" alt="Screenshot 2025-01-13 at 18 36 31" src="https://github.com/user-attachments/assets/66ab67cd-953b-406d-b2a6-7281e37696c1" />









<img width="558" alt="Screenshot 2025-01-13 at 18 37 04" src="https://github.com/user-attachments/assets/7ed774bb-71ee-45de-9ea7-3497f879cdf7" />








<img width="553" alt="Screenshot 2025-01-13 at 18 37 45" src="https://github.com/user-attachments/assets/2d96e5d9-9a37-4dfc-9990-b10206764367" />









<img width="552" alt="Screenshot 2025-01-13 at 19 14 29" src="https://github.com/user-attachments/assets/2fd9fc9c-eb01-48a4-9371-9dd64130c7f2" />









<img width="550" alt="Screenshot 2025-01-13 at 18 54 14" src="https://github.com/user-attachments/assets/0430adca-6440-4b18-8707-367bf5ae023c" />




<img width="560" alt="Screenshot 2025-01-13 at 20 09 19" src="https://github.com/user-attachments/assets/ad75ceb6-d59d-4ec0-be5e-b0796a5a3434" />








<img width="524" alt="Screenshot 2025-01-15 at 18 39 20" src="https://github.com/user-attachments/assets/44fea063-49e0-4015-bf1c-351815573085" />














<img width="526" alt="Screenshot 2025-01-13 at 20 14 17" src="https://github.com/user-attachments/assets/89a416f7-4b75-4e73-99f4-f2db3a1eaa03" />




<img width="528" alt="Screenshot 2025-01-15 at 18 30 26" src="https://github.com/user-attachments/assets/6fe261a3-3f08-43bd-bae1-d473c34c3af0" />






<img width="526" alt="Screenshot 2025-01-13 at 20 14 17" src="https://github.com/user-attachments/assets/89a416f7-4b75-4e73-99f4-f2db3a1eaa03" />





<img width="527" alt="Screenshot 2025-01-13 at 20 11 24" src="https://github.com/user-attachments/assets/421a539f-a968-4e33-b998-d128b105a27b" />




<img width="529" alt="Screenshot 2025-01-13 at 20 11 49" src="https://github.com/user-attachments/assets/ab1d5b5a-310d-4f95-a098-4a7afba590a6" />



<img width="526" alt="Screenshot 2025-01-13 at 20 12 15" src="https://github.com/user-attachments/assets/0fd1a891-e948-4336-b53f-d4579640c390" />

